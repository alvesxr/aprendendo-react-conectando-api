import axios from "axios"

const api = axios.create({
  baseURL: "http://localhost:3300/", // conecta com o backend pela url
})

export default api // Adicione esta linha para exportar como padrão