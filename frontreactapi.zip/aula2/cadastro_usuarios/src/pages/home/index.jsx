import { useEffect, useState } from 'react'//react hooks
import './style.css'
import api from '../../services/api'

function Home() { //função sempre começa com letra maiuscula

  const [users, setUsers] = useState([]) //useState é um hook do react que serve para criar variaveis de estado, o primeiro valor é o valor inicial e o segundo é a função que vai alterar esse valor

  async function getUsers() {
    const usersFromApi = await api.get('/usuarios')
    setUsers(usersFromApi.data)
  }

  useEffect(() => { //tudo que estiver dentro do useEffect vai ser executado quando o site carregar
     getUsers()
  }, [])

  return (
    <div className="container">
      <form>
        <h1>Cadastro de Usuários</h1>
          <input type="text" name="nome" placeholder='nome'/>
          <input type="number" name="idade" placeholder='idade'/>
          <input type="email" name="email" placeholder='email'/>
        <button type="button" className="btn-cadastrar">Cadastrar</button>
      </form>

      {users.map((user) => (
        <><div key={user.id_user} className="card">
          <p>Nome: <span>{user.name}</span></p>
          <p>Idade: <span>{user.age}</span></p>
          <p>Email: <span>{user.email}</span></p>
        </div>
        <button className="btn-excluir">Excluir</button></>
      ))}
    </div>
  )
}

export default Home
